# yapf:disable
log_config = dict(
    interval=50,# 打印日志的间隔
    hooks=[
        # dict(type='TextLoggerHook', by_epoch=False),
        dict(type='TensorboardLoggerHook')
    ])
# yapf:enable
dist_params = dict(backend='nccl')
log_level = 'INFO'
load_from = '/root/SegNeXt/mscan_l.pth'  #从一个给定路径里加载模型作为预训练模型，它并不会消耗训练时间。
resume_from = None  #从给定路径里恢复检查点(checkpoints)，训练模式将从检查点保存的轮次开始恢复训练。
workflow = [('train', 1)]
cudnn_benchmark = True #是否是使用 cudnn_benchmark 去加速，它对于固定输入大小的可以提高训练速度。
