import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat

from timm.models.layers import DropPath, to_2tuple, trunc_normal_
import timm

from mmseg.ops import resize
from ..builder import HEADS
from .decode_head import BaseDecodeHead

from mmcv.cnn import build_norm_layer
from mmcv.runner import BaseModule
from mmcv.cnn.bricks import DropPath
from mmcv.cnn.utils.weight_init import (constant_init, normal_init,
                                        trunc_normal_init)

class ConvBNGeLU(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, stride=1, norm_layer=nn.BatchNorm2d, bias=False):
        super(ConvBNGeLU, self).__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, bias=bias,
                      dilation=dilation, stride=stride, padding=((stride - 1) + dilation * (kernel_size - 1)) // 2),
            norm_layer(out_channels),
            nn.GELU()
        )

class ConvBN(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, stride=1, norm_layer=nn.BatchNorm2d, bias=False):
        super(ConvBN, self).__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, bias=bias,
                      dilation=dilation, stride=stride, padding=((stride - 1) + dilation * (kernel_size - 1)) // 2),
            norm_layer(out_channels)
        )


class Conv(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, stride=1, bias=False):
        super(Conv, self).__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, bias=bias,
                      dilation=dilation, stride=stride, padding=((stride - 1) + dilation * (kernel_size - 1)) // 2)
        )


class SeparableConvBNGeLU(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, dilation=1,
                 norm_layer=nn.BatchNorm2d):
        super(SeparableConvBNGeLU, self).__init__(
            nn.Conv2d(in_channels, in_channels, kernel_size, stride=stride, dilation=dilation,
                      padding=((stride - 1) + dilation * (kernel_size - 1)) // 2,
                      groups=in_channels, bias=False),
            norm_layer(out_channels),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.GELU()
        )

class SeparableConvBN(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, dilation=1,
                 norm_layer=nn.BatchNorm2d):
        super(SeparableConvBN, self).__init__(
            nn.Conv2d(in_channels, in_channels, kernel_size, stride=stride, dilation=dilation,
                      padding=((stride - 1) + dilation * (kernel_size - 1)) // 2,
                      groups=in_channels, bias=False),
            norm_layer(out_channels),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        )

class SeparableConv(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, dilation=1):
        super(SeparableConv, self).__init__(
            nn.Conv2d(in_channels, in_channels, kernel_size, stride=stride, dilation=dilation,
                      padding=((stride - 1) + dilation * (kernel_size - 1)) // 2,
                      groups=in_channels, bias=False),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        )


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=None, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Conv2d(in_features, hidden_features, 1, 1, 0, bias=True)
        self.act = nn.GELU()
        self.fc2 = nn.Conv2d(hidden_features, out_features, 1, 1, 0, bias=True)
        self.drop = nn.Dropout(drop, inplace=True)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x
    

class AttentionModule(BaseModule):
    def __init__(self, dim, eps=1e-8):
        super().__init__()
        # self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)
        
        self.conv0_1_1 =  nn.Conv2d(dim, dim, (1, 3), padding=(0, 1), groups=dim)
        self.conv0_1_2 =  nn.Conv2d(dim, dim, (3, 1), padding=(1, 0), groups=dim)
        self.conv0_2_1 =  nn.Conv2d(dim, dim, (1, 3), padding=(0, 3), groups=dim, dilation=3)
        self.conv0_2_2 =  nn.Conv2d(dim, dim, (3, 1), padding=(3, 0), groups=dim, dilation=3)
        # self.conv0_1 = nn.Conv2d(dim, dim, (1, 13), padding=(0, 6), groups=dim)
        # self.conv0_2 = nn.Conv2d(dim, dim, (13, 1), padding=(6, 0), groups=dim)

        self.conv1_1_1 = nn.Conv2d(dim, dim, (1, 3), padding=(0, 1), groups=dim)
        self.conv1_1_2 = nn.Conv2d(dim, dim, (3, 1), padding=(1, 0), groups=dim)
        self.conv1_2_1 = nn.Conv2d(dim, dim, (1, 5), padding=(0, 6), groups=dim, dilation=3)
        self.conv1_2_2 = nn.Conv2d(dim, dim, (5, 1), padding=(6, 0), groups=dim, dilation=3)
        # self.conv1_1 = nn.Conv2d(dim, dim, (1, 27), padding=(0, 13), groups=dim)
        # self.conv1_2 = nn.Conv2d(dim, dim, (27, 1), padding=(13, 0), groups=dim)

        self.conv2_1_1 = nn.Conv2d(dim, dim, (1, 3), padding=(0, 1), groups=dim)
        self.conv2_1_2 = nn.Conv2d(dim, dim, (3, 1), padding=(1, 0), groups=dim)
        self.conv2_2_1 = nn.Conv2d(dim, dim, (1, 7), padding=(0, 9), groups=dim, dilation=3)
        self.conv2_2_2 = nn.Conv2d(dim, dim, (7, 1), padding=(9, 0), groups=dim, dilation=3)
        # self.conv2_1 = nn.Conv2d(
        #     dim, dim, (1, 31), padding=(0, 15), groups=dim)
        # self.conv2_2 = nn.Conv2d(
        #     dim, dim, (31, 1), padding=(15, 0), groups=dim)
        self.conv3 = nn.Conv2d(dim, dim, 1)
        
        self.weights = nn.Parameter(torch.ones(4, dtype=torch.float32), requires_grad=True)
        self.eps=1e-8

    def forward(self, x): #输入256*256
        u = x.clone()#保留输入特征
        # attn = self.conv0(x)#5*5卷积 pad=2 stride默认为1 
        attn = x

        attn_0 = self.conv0_1_1(attn)
        attn_0 = self.conv0_1_2(attn_0)
        attn_0 = self.conv0_2_1(attn_0)
        attn_0 = self.conv0_2_2(attn_0)

        attn_1 = self.conv1_1_1(attn)
        attn_1 = self.conv1_1_2(attn_1)
        attn_1 = self.conv1_2_1(attn_1)
        attn_1 = self.conv1_2_2(attn_1)

        attn_2 = self.conv2_1_1(attn)
        attn_2 = self.conv2_1_2(attn_2)
        attn_2 = self.conv2_2_1(attn_2)
        attn_2 = self.conv2_2_2(attn_2)
        
        #这里加一个GelU的作用是什么 条件允许的话可以做一下实验 也可以换一下GeLU
        weights = F.gelu(self.weights)
        sum_weights = weights / (torch.sum(weights, dim=0)+self.eps) #这里在WF中加了一个1e-8
        attn = attn*sum_weights[0] + attn_0*sum_weights[1] + attn_1*sum_weights[2] + attn_2*sum_weights[3]
        # attn = attn + attn_0 + attn_1 + attn_2 #1这里改成权重和

        attn = self.conv3(attn)

        return attn * u
    
class GlobalLocalConv(nn.Module):
    def __init__(self,dim=256, eps=1e-8):
        super().__init__()
        self.local1 = ConvBN(dim, dim, kernel_size=3) #1*1 conv 这里也可以改成条状卷积，但是必要性有限
        self.local2 = ConvBN(dim, dim, kernel_size=1) #3*3 conv
        self.proj = SeparableConvBN(dim, dim, kernel_size=8) #两个分支concact后的那个模块 conv 改成一个8*8的卷积（这里的大小或许可以调整）
        self.attn = AttentionModule(dim)
        
        self.local_weights = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        # self.weights = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.eps=1e-8
    
    def pad_out(self, x): #作用有待考证
        x = F.pad(x, pad=(0, 1, 0, 1), mode='reflect')  #对H和W进行长度为1的reflect填充
        return x

    def forward(self, x):
        B, C, H, W = x.shape
        
        local_weights = F.gelu(self.local_weights)
        sum_weights = local_weights / (torch.sum(local_weights, dim=0)+self.eps)
        #把CNN的local figure先算出来
        local = self.local2(x)*sum_weights[0] + self.local1(x)*sum_weights[1] #3这里也可以改成权重
        #local = self.local2(x) + self.local1(x)
        
        out = self.attn(x)
        
        # weights = F.gelu()(self.weights)
        # sum_weights = weights / (torch.sum(weights, dim=0)+self.eps) #这里在WF中加了一个1e-8
        
        # out = out*sum_weights[0] + local*sum_weights[1]
        out = out + local #2改成权重和
        out = self.pad_out(out)
        out = self.proj(out)
        out = out[:, :, :H, :W]

        return out


class Block(nn.Module):
    def __init__(self, dim=256, num_heads=16,  mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=None, norm_layer=nn.BatchNorm2d, window_size=8):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = GlobalLocalConv(dim)

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, out_features=dim, act_layer=act_layer, drop=drop)
        self.norm2 = norm_layer(dim)

    def forward(self, x):

        x = x + self.drop_path(self.attn(self.norm1(x)))
        x = x + self.drop_path(self.mlp(self.norm2(x)))

        return x


class WF(nn.Module):
    def __init__(self, in_channels=128, decode_channels=128, eps=1e-8):
        super(WF, self).__init__()
        self.pre_conv = Conv(in_channels, decode_channels, kernel_size=1)

        self.weights = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True) #设置一个大小为2的张量为可训练参数，作为weight
        self.eps = eps
        self.post_conv = ConvBNGeLU(decode_channels, decode_channels, kernel_size=3)

    def forward(self, x, res):
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=False) #插值函数 放大倍数为2
        weights = F.gelu(self.weights) #将weight过Gelu，加入非线性
        fuse_weights = weights / (torch.sum(weights, dim=0) + self.eps) #加的这个参数目的是保证没有0 但这里算的是alpha和1-alpha
        x = fuse_weights[0] * self.pre_conv(res) + fuse_weights[1] * x #resnet的输出和decoder的输出
        x = self.post_conv(x)#过一个Gelu
        return x


class FeatureRefinementHead(nn.Module):
    def __init__(self, in_channels=64, decode_channels=64):
        super().__init__()
        self.pre_conv = Conv(in_channels, decode_channels, kernel_size=1)

        self.weights = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.eps = 1e-8
        self.post_conv = ConvBNGeLU(decode_channels, decode_channels, kernel_size=3)

        self.pa = nn.Sequential(nn.Conv2d(decode_channels, decode_channels, kernel_size=3, padding=1, groups=decode_channels),
                                nn.Sigmoid())
        self.ca = nn.Sequential(nn.AdaptiveAvgPool2d(1),
                                Conv(decode_channels, decode_channels//16, kernel_size=1),
                                nn.GELU(),
                                Conv(decode_channels//16, decode_channels, kernel_size=1),
                                nn.Sigmoid())

        self.shortcut = ConvBN(decode_channels, decode_channels, kernel_size=1)
        self.proj = SeparableConvBN(decode_channels, decode_channels, kernel_size=3)
        self.act = nn.GELU() #这里nn.GELU()是定义了一个对象，可以被当作参数传递，而F.gelu()本身就是一个函数，使用的隔阂死后必须穿入参数，没办法像nn一样传来传去

    def forward(self, x, res):
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=False)
        weights = F.gelu(self.weights)
        fuse_weights = weights / (torch.sum(weights, dim=0) + self.eps)
        x = fuse_weights[0] * self.pre_conv(res) + fuse_weights[1] * x
        x = self.post_conv(x)
        shortcut = self.shortcut(x)
        pa = self.pa(x) * x
        ca = self.ca(x) * x
        x = pa + ca
        x = self.proj(x) + shortcut
        x = self.act(x)

        return x


class AuxHead(nn.Module):

    def __init__(self, in_channels=64, num_classes=8):
        super().__init__()
        self.conv = ConvBNGeLU(in_channels, in_channels)
        self.drop = nn.Dropout(0.1)
        self.conv_out = Conv(in_channels, num_classes, kernel_size=1)

    def forward(self, x, h, w):
        feat = self.conv(x)
        feat = self.drop(feat)
        feat = self.conv_out(feat)
        feat = F.interpolate(feat, size=(h, w), mode='bilinear', align_corners=False)
        return feat


class Decoder(nn.Module):
    def __init__(self,
                 encoder_channels=(64, 128, 256, 512),
                 decode_channels=64,
                 dropout=0.1,
                 window_size=8,
                 num_classes=6):
        super(Decoder, self).__init__()

        self.pre_conv = ConvBN(encoder_channels[-1], decode_channels, kernel_size=1)
        self.b4 = Block(dim=decode_channels, num_heads=8, window_size=window_size)

        self.b3 = Block(dim=decode_channels, num_heads=8, window_size=window_size)
        self.p3 = WF(encoder_channels[-2], decode_channels)

        self.b2 = Block(dim=decode_channels, num_heads=8, window_size=window_size)
        self.p2 = WF(encoder_channels[-3], decode_channels)

        if self.training:
            self.up4 = nn.UpsamplingBilinear2d(scale_factor=4)
            self.up3 = nn.UpsamplingBilinear2d(scale_factor=2)
            # self.aux_head = AuxHead(decode_channels, num_classes)

        # self.p1 = FeatureRefinementHead(encoder_channels[-4], decode_channels)

        self.segmentation_head = nn.Sequential(ConvBNGeLU(decode_channels, decode_channels),
                                               nn.Dropout2d(p=dropout, inplace=True),
                                               Conv(decode_channels, num_classes, kernel_size=1))
        self.init_weight()

    def forward(self, res1, res2, res3, res4, h, w):
        if self.training:
            x = self.b4(self.pre_conv(res4)) #4是最下面最小的一层
            h4 = self.up4(x)

            x = self.p3(x, res3)
            x = self.b3(x)
            h3 = self.up3(x)

            x = self.p2(x, res2)
            x = self.b2(x)
            h2 = x
            # x = self.p1(x, res1)
            x = self.segmentation_head(x)
            x = F.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)

            # ah = h4 + h3 + h2
            # ah = self.aux_head(ah, h, w) #过aux

            return x
        else:
            x = self.b4(self.pre_conv(res4))
            x = self.p3(x, res3)
            x = self.b3(x)

            x = self.p2(x, res2)
            x = self.b2(x)

            # x = self.p1(x, res1)

            x = self.segmentation_head(x)
            x = F.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)

            return x

    def init_weight(self):
        for m in self.children():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, a=1)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

@HEADS.register_module()
class UnetFormerConvHead(BaseDecodeHead):
    def __init__(self,
                 decode_channels=64,
                 dropout=0.1,
                 # backbone_name='swsl_resnet18',
                 pretrained=True,
                 window_size=8,
                 # num_classes=6,
                 **kwargs
                 ):
        print(kwargs)
        super(UnetFormerConvHead, self).__init__(input_transform='multiple_select', **kwargs)
        self.decode_channels = decode_channels
        #这里存在stage数量的问题，segnext里只传了三个stage但是unetformer传了四个
        # self.backbone = timm.create_model(backbone_name, features_only=True, output_stride=32,
        #                                   out_indices=(1, 2, 3, 4), pretrained=pretrained)
        # encoder_channels = self.backbone.feature_info.channels()
        #参数里self.num_classes无法设置为6，所以这里直接用了传入的预设参数num_classes
        self.decoder = Decoder(self.in_channels, decode_channels, dropout, window_size, self.num_classes)

    def forward(self, x):
        print("===decoder running===")
        #处理encoder的输出，将每一层的结果保存下来，做成一个list/元组？
        x = self._transform_inputs(x)
        print("===decoder x===")
        print(len(x))
        print(x[0].size())
        #这里原本的是x.size()[-2:]
        h, w = x[0].size()[-2:]
        print(h)
        print(w)
        #方案一：保持segnext中对于最后一层信息无用的判断，只传入三层数据，将res2的处理删除
        
        #方案二：保持unetformer中对所有层（优先采用了该方案，因为unetformer中存在权重）
        res1 = x[0]
        res2 = x[1]
        res3 = x[2]
        res4 = x[3]
        # res1, res2, res3, res4 = self.backbone(x)
        if self.training:
            x= self.decoder(res1, res2, res3, res4, h, w)
            print("===decoder output x===")
            print(x.shape)
            # return x, ah 这里增加的是一个segnext里设计的loss函数，在segmm中暂时先不使用，直接用cross entropy
            return x
        else:
            x = self.decoder(res1, res2, res3, res4, h, w)
            return x